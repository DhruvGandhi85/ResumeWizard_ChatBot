"use client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"

type Suggestion = {
  section: string
  original: string
  suggestion: string
  reason: string
}

interface SuggestionPanelProps {
  suggestions: Suggestion[]
}

export function SuggestionPanel({ suggestions }: SuggestionPanelProps) {
  const sectionGroups = suggestions.reduce(
    (acc, suggestion) => {
      if (!acc[suggestion.section]) {
        acc[suggestion.section] = []
      }
      acc[suggestion.section].push(suggestion)
      return acc
    },
    {} as Record<string, Suggestion[]>,
  )

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Resume Improvement Suggestions</CardTitle>
          <CardDescription>
            We analyzed your resume and found {suggestions.length} potential improvements
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Accordion type="single" collapsible className="w-full">
            {Object.entries(sectionGroups).map(([section, sectionSuggestions], index) => (
              <AccordionItem key={index} value={`section-${index}`}>
                <AccordionTrigger className="hover:no-underline">
                  <div className="flex items-center">
                    <span>{section}</span>
                    <Badge variant="secondary" className="ml-2">
                      {sectionSuggestions.length}
                    </Badge>
                  </div>
                </AccordionTrigger>
                <AccordionContent>
                  <div className="space-y-4">
                    {sectionSuggestions.map((suggestion, idx) => (
                      <Card key={idx} className="border border-muted">
                        <CardContent className="pt-6">
                          <div className="space-y-4">
                            <div>
                              <h4 className="text-sm font-medium text-muted-foreground mb-1">Original</h4>
                              <p className="text-sm bg-muted p-3 rounded-md">{suggestion.original}</p>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium text-primary mb-1">Suggested Improvement</h4>
                              <p className="text-sm bg-primary/10 p-3 rounded-md">{suggestion.suggestion}</p>
                            </div>
                            <div>
                              <h4 className="text-sm font-medium text-muted-foreground mb-1">Reason</h4>
                              <p className="text-sm">{suggestion.reason}</p>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </CardContent>
      </Card>
    </div>
  )
}

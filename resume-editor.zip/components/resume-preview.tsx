"use client"

import { useState } from "react"
import { Card } from "@/components/ui/card"
import { Loader2 } from "lucide-react"

interface ResumePreviewProps {
  fileUrl: string
}

export function ResumePreview({ fileUrl }: ResumePreviewProps) {
  const [loading, setLoading] = useState(true)

  return (
    <Card className="overflow-hidden border rounded-lg">
      <div className="relative bg-muted min-h-[500px] w-full">
        {loading && (
          <div className="absolute inset-0 flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        )}
        <iframe src={fileUrl} className="w-full h-[700px]" onLoad={() => setLoading(false)} title="Resume Preview" />
      </div>
    </Card>
  )
}

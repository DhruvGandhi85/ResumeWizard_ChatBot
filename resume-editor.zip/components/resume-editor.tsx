"use client"

import { useState } from "react"
import { FileUploader } from "./file-uploader"
import { ResumePreview } from "./resume-preview"
import { SuggestionPanel } from "./suggestion-panel"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { analyzeResume } from "@/app/actions"
import { Loader2 } from "lucide-react"

type Suggestion = {
  section: string
  original: string
  suggestion: string
  reason: string
}

export function ResumeEditor() {
  const [file, setFile] = useState<File | null>(null)
  const [fileUrl, setFileUrl] = useState<string | null>(null)
  const [suggestions, setSuggestions] = useState<Suggestion[]>([])
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [activeTab, setActiveTab] = useState("upload")

  const handleFileUpload = (uploadedFile: File) => {
    setFile(uploadedFile)
    const url = URL.createObjectURL(uploadedFile)
    setFileUrl(url)
    setActiveTab("preview")
  }

  const handleAnalyze = async () => {
    if (!file) return

    setIsAnalyzing(true)
    try {
      const formData = new FormData()
      formData.append("pdf", file)

      const result = await analyzeResume(formData)
      setSuggestions(result.suggestions)
      setActiveTab("suggestions")
    } catch (error) {
      console.error("Error analyzing resume:", error)
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <div className="space-y-6">
      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="upload">Upload</TabsTrigger>
          <TabsTrigger value="preview" disabled={!fileUrl}>
            Preview
          </TabsTrigger>
          <TabsTrigger value="suggestions" disabled={suggestions.length === 0}>
            Suggestions
          </TabsTrigger>
        </TabsList>

        <TabsContent value="upload" className="pt-4">
          <FileUploader onFileUpload={handleFileUpload} />
        </TabsContent>

        <TabsContent value="preview" className="pt-4">
          {fileUrl && (
            <div className="space-y-6">
              <ResumePreview fileUrl={fileUrl} />
              <div className="flex justify-center">
                <Button onClick={handleAnalyze} disabled={isAnalyzing} className="w-full max-w-xs">
                  {isAnalyzing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Analyzing Resume...
                    </>
                  ) : (
                    "Get Suggestions"
                  )}
                </Button>
              </div>
            </div>
          )}
        </TabsContent>

        <TabsContent value="suggestions" className="pt-4">
          {suggestions.length > 0 && <SuggestionPanel suggestions={suggestions} />}
        </TabsContent>
      </Tabs>
    </div>
  )
}

"use client"

import { useState, useCallback } from "react"
import { useDropzone } from "react-dropzone"
import { FileText, Upload } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"

interface FileUploaderProps {
  onFileUpload: (file: File) => void
}

export function FileUploader({ onFileUpload }: FileUploaderProps) {
  const [dragActive, setDragActive] = useState(false)

  const onDrop = useCallback(
    (acceptedFiles: File[]) => {
      if (acceptedFiles && acceptedFiles.length > 0) {
        const file = acceptedFiles[0]
        if (file.type === "application/pdf") {
          onFileUpload(file)
        }
      }
    },
    [onFileUpload],
  )

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
    },
    maxFiles: 1,
  })

  return (
    <Card className={`border-2 border-dashed ${isDragActive ? "border-primary" : "border-muted-foreground/25"}`}>
      <CardContent className="p-6">
        <div
          {...getRootProps()}
          className="flex flex-col items-center justify-center space-y-4 py-12 text-center cursor-pointer"
        >
          <input {...getInputProps()} />
          <div className="rounded-full bg-primary/10 p-4">
            <FileText className="h-10 w-10 text-primary" />
          </div>
          <div className="space-y-2">
            <h3 className="text-lg font-semibold">Upload your resume</h3>
            <p className="text-sm text-muted-foreground">Drag and drop your PDF resume here, or click to browse</p>
          </div>
          <Button variant="outline" className="mt-2">
            <Upload className="mr-2 h-4 w-4" />
            Select PDF
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}

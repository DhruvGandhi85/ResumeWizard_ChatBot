import { ResumeEditor } from "@/components/resume-editor"

export default function Home() {
  return (
    <main className="container mx-auto py-10 px-4 md:px-6">
      <div className="max-w-5xl mx-auto">
        <div className="space-y-2 text-center mb-10">
          <h1 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Resume Editor</h1>
          <p className="text-muted-foreground">Upload your resume and get AI-powered suggestions to improve it.</p>
        </div>
        <ResumeEditor />
      </div>
    </main>
  )
}

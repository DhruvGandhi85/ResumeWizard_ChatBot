"use server"

import { generateObject } from "ai"
import { openai } from "@ai-sdk/openai"
import { z } from "zod"

type Suggestion = {
  section: string
  original: string
  suggestion: string
  reason: string
}

type AnalysisResult = {
  suggestions: Suggestion[]
}

export async function analyzeResume(formData: FormData): Promise<AnalysisResult> {
  try {
    const file = formData.get("pdf") as File

    if (!file) {
      throw new Error("No PDF file provided")
    }

    const result = await generateObject({
      model: openai("gpt-4o"),
      messages: [
        {
          role: "user",
          content: [
            {
              type: "text",
              text: "Analyze this resume and provide specific suggestions for improvement. Focus on content, formatting, clarity, and impact. Identify weak points and suggest better alternatives.",
            },
            {
              type: "file",
              data: await file.arrayBuffer(),
              mimeType: "application/pdf",
            },
          ],
        },
      ],
      schema: z.object({
        suggestions: z
          .array(
            z.object({
              section: z
                .string()
                .describe(
                  "The section of the resume this suggestion applies to (e.g., 'Summary', 'Experience', 'Skills', etc.)",
                ),
              original: z.string().describe("The original text or content from the resume"),
              suggestion: z.string().describe("The suggested improvement"),
              reason: z.string().describe("Why this change would improve the resume"),
            }),
          )
          .describe("A list of specific suggestions to improve the resume"),
      }),
    })

    return {
      suggestions: result.object.suggestions,
    }
  } catch (error) {
    console.error("Error analyzing resume:", error)
    return { suggestions: [] }
  }
}
